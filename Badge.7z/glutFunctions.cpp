﻿#if defined(_MSC_VER)
#include <GL/glew.h>
#endif
#include <GL/glut.h>

#include <iostream>
#include "Constant.h"

extern void Render(void);
extern void KeyEnter(unsigned char key, int x, int y);
extern void HandleLeftClick(int x,int y);
extern bool Idle();

void MouseClick(int button, int state,int x, int y)
{
    std::cout << button << " " << state << " " << x << " " << y << std::endl;
	if(button == GLUT_LEFT_BUTTON && state ==  GLUT_UP)
		HandleLeftClick(x,y);
}

void glutIdle()
{
	if(Idle())
	{
		//glutSwapBuffers();
		GLenum err = glGetError();
		if (err != GL_NO_ERROR)
		{
			std::cout << "GL Error: " << gluErrorString(err) << std::endl;
		}
        //glutPostRedisplay();
	}
}

void InitGL(int* argc, char *argv[])
{
	int win;

	glutInit(argc, argv);

	glutInitDisplayMode(GLUT_RGB);
	glutInitWindowSize(SIZE_X,SIZE_Y);
	win = glutCreateWindow("RasterBadge");

#if defined(_MSC_VER)
	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
		fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
	}
#endif

	#ifdef ON_PI
	glutFullScreen();
	#endif

	glDisable(GL_DEPTH_TEST);


	glClearColor(0.0,0.0,0.0,0.0);
	gluOrtho2D(0,SIZE_X,0,SIZE_Y);
	glViewport(0,0,SIZE_X,SIZE_Y);
	glutDisplayFunc(Render);
	glutIdleFunc(glutIdle);

	//input
	glutKeyboardFunc(KeyEnter);
	glutMouseFunc(MouseClick); //Only care about left click

	std::cout << glGetString(GL_RENDERER) << std::endl;
	std::cout << glGetString(GL_VERSION) << std::endl;

}

void StartMainLoop()
{
	glutMainLoop();
}
