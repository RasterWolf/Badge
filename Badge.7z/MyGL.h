﻿#pragma once
#if defined(_MSC_VER)
#include <GL/glew.h>
#include <GL/glut.h>
#else
#include <GLES2/gl2.h>
#endif

