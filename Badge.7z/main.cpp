#include <iostream>
#include <cstdlib>
#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>
//#include <GL/glew.h>
//#include <GL/gl.h>
#include <stdlib.h>
#include <time.h>


#include "MyGL.h"

using namespace std;

//My stuff
#include "Shaders.h"
#include "TextureManager.h"
#include "BadgePrograms.h"
#include "Constant.h"


extern void InitGL(int* argc, char *argv[]);
extern void StartMainLoop();

BadgeProgram* bb;

void Quit()
{
	TextureManager::DeleteTextureManager();
	ShaderPrograms::DeleteShaderPrograms();
	SDL_Quit();
	exit(0);
}

const unsigned int LastRenderTime = 0;
const unsigned int FPS = 30;
const unsigned int FrameTime = 1000/FPS;
const float TickTime = 1000.0f / FPS;

bool Idle()
{
    unsigned int Start  = SDL_GetTicks();
    bool draw = false;
	draw |= bb->Integrate(TickTime);
	if(draw)
	{
        bb->DoYourThing(TickTime);
        glFlush();
	}

	auto diff = SDL_GetTicks() - Start;

    #ifdef ON_PI
    if(diff > FrameTime)
        std::cout << Start << " " << SDL_GetTicks() << " " << diff << std::endl;
    #endif
	if(diff< FrameTime)
	{
		SDL_Delay(FrameTime - diff);
	}

	return draw;
}

void Render(void)
{
	unsigned int Start  = SDL_GetTicks();

	{
        bb->DoYourThing(TickTime);
        glFlush();
	}

	unsigned int diff = SDL_GetTicks() - Start;

	if(diff< FrameTime)
	{
		SDL_Delay(FrameTime - diff);
	}
}

void KeyEnter(unsigned char key, int x, int y)
{
  if( key == 'q' ) Quit();
  if (key == 'r')
  {
	  ShaderPrograms::DeleteShaderPrograms();
	  ShaderPrograms::InitShaderPrograms();
  }
  bb->HandleKeyPress(key);
}

void HandleLeftClick(int x, int y)
{
	bb->HandleClick(x,y);
}

int main(int argc, char *argv[])
{
	srand(time(nullptr));
	SDL_Init(SDL_INIT_TIMER);
	InitGL(&argc,argv);
	ShaderPrograms::InitShaderPrograms();
	TextureManager::InitTextureManager();

	RasterBadge Raster;
	PulexBadge pb;
	bb = (BadgeProgram*)&pb;

	StartMainLoop();

	return 0;
}
