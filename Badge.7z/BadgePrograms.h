﻿#pragma once
#include <string>
#include "TextureManager.h"
#include "BasicActors.h"
#include "Math.h"
#include <list>

class BadgeProgram
{
public:
	virtual void HandleClick(int x, int y) { ; }
	virtual void HandleKeyPress(unsigned char key) {;}
	virtual void DoYourThing(float delta)=0;
	virtual bool Integrate(float delta){ return false;}
};

class BasicBadge : public BadgeProgram
{
public:
	BasicBadge(const std::string backgroundImage);
	~BasicBadge() { ; }
	bool Integrate(float delta) override 
	{ 
		return BadgeProgram::Integrate(delta);
	}
	void DoYourThing(float delta) override;
private:
	BadgeImage BackgroundTexture;
};

class TempImageActor : public ImageActor
{
public:
	TempImageActor(const std::string& image) : ImageActor(image)
	{

	}
	void Init(const glm::vec2& Position);
	bool Integrate(float tick) override;
	float TimeSinceStart;
	bool bEnabled;
};

template<typename ImgType>
class TempImageBadge : public BasicBadge
{
	typedef BasicBadge super;
public:
	TempImageBadge(const std::string& image) : BasicBadge(image)
		, renderNextFrame(false)
	{
		;
	}
	void DoYourThing(float delta) override
	{
		super::DoYourThing(delta);

		for (auto& bp : SpawnedActors)
		{
			if (bp->bEnabled)
				bp->Render();
		}
	}

	bool Integrate(float delta) override
	{
		bool b = renderNextFrame;
		renderNextFrame = false;
		b |= super::Integrate(delta);
		auto i = SpawnedActors.begin();
		while (i != SpawnedActors.end())
		{
			if ((*i)->bEnabled)
			{
				b |= (*i)->Integrate(delta);
				if (!(*i)->bEnabled)
					SpawnedActors.erase(i++);  // alternatively, i = items.erase(i);
				else
					i++;
			}

			renderNextFrame = SpawnedActors.size() == 0;
		}

		return b;
	}
protected:
	ImgType AllTempActor[10];
	std::list<TempImageActor*> SpawnedActors;
	bool renderNextFrame;


};

//Raster

class BoopActor : public TempImageActor
{
public:
	BoopActor()
	: TempImageActor("BoopBubble.png")
	{
		bEnabled = false;
		TimeSinceStart = 0.0f;
	}
};

class RasterBadge : public TempImageBadge<BoopActor>
{
public:
	RasterBadge()
		: TempImageBadge<BoopActor>("RasterBadge.png")
	{
		;
	}
	~RasterBadge(){;}
	void HandleClick(int x, int y) override;
private:
	static glm::vec2 NoseMin;
	static glm::vec2 NoseSize;

};

//Pulex

class HeartActor : public TempImageActor
{
public:
	HeartActor()
		: TempImageActor("Heart.png")
		, color(1.0f)
	{
		bEnabled = false;
		TimeSinceStart = 0.0f;
	}

	void Render() override;
	glm::vec3 color;
};

class PulexBadge : public TempImageBadge<HeartActor>
{
public:
	PulexBadge() : TempImageBadge<HeartActor>("PulexBadge.png")
	{
		;
	}
	~PulexBadge() { ; }
	void HandleClick(int x, int y) override;
private:
	static glm::vec2 HeartMin;
	static glm::vec2 HeartSize;
};
